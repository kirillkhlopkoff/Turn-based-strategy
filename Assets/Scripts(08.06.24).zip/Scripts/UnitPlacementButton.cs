using UnityEngine;
using UnityEngine.UI;

public class UnitPlacementButton : MonoBehaviour
{
    //public GameUnit unitPrefab;
    //private BattlefieldBoardManager boardManager;

    //void Start()
    //{
    //    boardManager = FindObjectOfType<BattlefieldBoardManager>();
    //    GetComponent<Button>().onClick.AddListener(OnButtonClick);
    //}

    //void OnButtonClick()
    //{
    //    boardManager.StartPlacingUnit(unitPrefab);
    //}
}
